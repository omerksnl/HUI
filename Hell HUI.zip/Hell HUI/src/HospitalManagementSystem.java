public class HospitalManagementSystem {
    public static void main(String[] args) {
        Doctor doctor = new Doctor("Head Doctor","Oktay");
        HospitalGUI view = new HospitalGUI();
        HospitalController controller = new HospitalController(view, doctor);
        Patient test=new Patient("test","şanal",12,"9","Male","Dent");
        doctor.addPatient(test);
        view.setVisible(true);
    }
}
