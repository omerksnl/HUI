import javax.swing.*;
import java.awt.*;

public class HospitalGUI extends JFrame {
    private JTextField NameField = new JTextField();
    private JTextField SurnameField = new JTextField();
    private JTextField AgeField = new JTextField();
    private JTextField ContactField = new JTextField();
    private JComboBox<String> GenderField = new JComboBox<>(new String[]{"Male", "Female", "I Don't Want To Mention"});
    private JTextField DoctorCategoryField = new JTextField();
    private JButton submitButton = new JButton("Submit Info");
    private JButton updateButton = new JButton("Update Info");
    private JButton deleteButton = new JButton("Delete Info");
    private JTextArea displayArea = new JTextArea( );
    private JTextField doctorPatientIdField = new JTextField();
    private JButton fetchPatientDetailsButton = new JButton("Fetch Patient Details");
    private JTextArea doctorDisplayArea = new JTextArea();
    private JButton prescriptionButton = new JButton("Prescription");
    private JButton commentsButton = new JButton("Comments");
    private JButton nextCheckupButton = new JButton("Next Checkup");
    private JButton seeComments= new JButton("See The Comments from Doctor");

    public HospitalGUI() {
        setTitle("Hospital Management System");
        setSize(800, 700);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        JTabbedPane tabbed = new JTabbedPane();
        JPanel patientPanel = new JPanel();
        patientPanel.setSize(800,600);
        patientPanel.setLayout(new GridLayout(9, 2));
        patientPanel.add(new JLabel("Name:"));
        patientPanel.add(NameField);
        patientPanel.add(new JLabel("Surname:"));
        patientPanel.add(SurnameField);
        patientPanel.add(new JLabel("Age:"));
        patientPanel.add(AgeField);
        patientPanel.add(new JLabel("Contact Info:"));
        patientPanel.add(ContactField);
        patientPanel.add(new JLabel("Gender:"));
        patientPanel.add(GenderField);
        patientPanel.add(new JLabel("Doctor Category:"));
        patientPanel.add(DoctorCategoryField);
        patientPanel.add(submitButton);
        patientPanel.add(updateButton);
        patientPanel.add(deleteButton);
        patientPanel.add(seeComments);
        patientPanel.add(new JScrollPane(displayArea));
        tabbed.addTab("Patient", patientPanel);
        JPanel doctorPanel = new JPanel();
        doctorPanel.setLayout(new GridLayout(6, 2));
        doctorPanel.add(new JLabel("Patient ID:"));
        doctorPanel.add(doctorPatientIdField);
        doctorPanel.add(fetchPatientDetailsButton);
        doctorPanel.add(new JScrollPane(doctorDisplayArea));
        doctorPanel.add(prescriptionButton);
        doctorPanel.add(commentsButton);
        doctorPanel.add(nextCheckupButton);
        tabbed.addTab("Doctor", doctorPanel);
        add(tabbed, BorderLayout.CENTER);
        setVisible(true);
    }
    public String getPatientName() {
        return NameField.getText();
    }

    public String getPatientSurname() {
        return SurnameField.getText();
    }

    public int getPatientAge() {
        return Integer.parseInt(AgeField.getText());
    }

    public String getPatientContact() {
        return ContactField.getText();
    }

    public String getPatientGender() {
        return (String) GenderField.getSelectedItem();
    }

    public String getPatientDoctorCategory() {
        return DoctorCategoryField.getText();
    }

    public JButton getSeeComments() {
        return seeComments;
    }

    public JButton getSubmitButton() {
        return submitButton;
    }

    public JButton getUpdateButton() {
        return updateButton;
    }

    public JButton getDeleteButton() {
        return deleteButton;
    }

    public void displayPatientInfo(String info) {
        displayArea.append(info + "\n");
    }

    public void showError(String errorMessage) {
        JOptionPane.showMessageDialog(this, errorMessage);
    }

    public String getDoctorPatientId() {
        return doctorPatientIdField.getText();
    }

    public JButton getFetchPatientDetailsButton() {
        return fetchPatientDetailsButton;
    }

    public JButton getPrescriptionButton() {
        return prescriptionButton;
    }

    public JButton getCommentsButton() {
        return commentsButton;
    }

    public JButton getNextCheckupButton() {
        return nextCheckupButton;
    }

    public void displayDoctorInfo(String info) {
        doctorDisplayArea.append(info + "\n");
    }
}
