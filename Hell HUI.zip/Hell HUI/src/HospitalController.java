import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;


public class HospitalController {
    private HospitalGUI gui;
    public  Doctor doctor;

    public HospitalController(HospitalGUI GUI, Doctor doctor) {
        /*boolean a=true;
        while (a){
            String name=JOptionPane.showInputDialog(null,"Enter your Name");
            if(name.equals(doctor.getName())){
                JOptionPane.showMessageDialog(null,"Hi,doc!!!");
                String cat=JOptionPane.showInputDialog(null,"Enter your Cat.");
                if (cat.equals(doctor.getCategory())){
                    a=false;
                }else JOptionPane.showMessageDialog(null,"Bro really thought he was the doc");
            }else JOptionPane.showMessageDialog(null,"Who are you broooo");
        }*/
        this.gui = GUI;
        this.doctor = doctor;
        this.gui.getSubmitButton().addActionListener(new SubmitButtonListener());
        this.gui.getUpdateButton().addActionListener(new UpdateButtonListener());
        this.gui.getDeleteButton().addActionListener(new DeleteButtonListener());
        this.gui.getFetchPatientDetailsButton().addActionListener(new FetchPatientDetailsListener());
        this.gui.getPrescriptionButton().addActionListener(new PrescriptionButtonListener());
        this.gui.getCommentsButton().addActionListener(new CommentsButtonListener());
        this.gui.getNextCheckupButton().addActionListener(new NextCheckupButtonListener());
        this.gui.getSeeComments().addActionListener(new SeeCommentsListener());
    }
    class SeeCommentsListener implements  ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            try {
                String patientIdStr = JOptionPane.showInputDialog("Enter your patient ID:");
                if (patientIdStr != null) {
                    int patientId = Integer.parseInt(patientIdStr);
                    Patient patient = doctor.getPatientById(patientId);
                    for (String comments : patient.getComments()) {
                       gui.displayPatientInfo(comments);
                    }
                }
            } catch (IllegalArgumentException a) {
                gui.showError("Write your ID properly! ");
            }
        }
    }
    class SubmitButtonListener implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            try {
                String name = gui.getPatientName();
                String surname = gui.getPatientSurname();
                String ageString = String.valueOf(gui.getPatientAge());
                String contactInfo = gui.getPatientContact();
                String gender = gui.getPatientGender();
                String doctorCategory = gui.getPatientDoctorCategory();
                if (name.isEmpty() || surname.isEmpty() || ageString.isEmpty() || contactInfo.isEmpty() || gender.isEmpty() || doctorCategory.isEmpty()) {
                    throw new IllegalArgumentException("All fields must be filled out.");
                }
                int age;
                try {
                    age = Integer.parseInt(ageString);
                    if (age <= 0) {
                        throw new NumberFormatException();
                    }
                } catch (NumberFormatException ex) {
                    throw new IllegalArgumentException("Invalid age. Age must be a positive integer.");
                }
                try {
                    age=Integer.parseInt(ageString);
                    if (age >= 1000){
                        throw new NumberFormatException();
                    }
                } catch (NumberFormatException exception){
                    throw new IllegalArgumentException("Bro are you a dino? :D");
                }
                Patient newPatient = new Patient( name, surname, age, contactInfo, gender, doctorCategory);
                doctor.addPatient(newPatient);
                gui.displayPatientInfo("Patient added: " + newPatient.getName() + " " + newPatient.getSurname() + "  with ID " + newPatient.getPatientId()+"\n, Age: "+newPatient.getAge()+", Cont. Info: "+ newPatient.getContactInfo()+", Gender "+newPatient.getGender()+", Doc. Category "+newPatient.getDoctorCategory());
                gui.showError("A new challenger (new patient) has come (｡ >﹏<)");

            } catch (IllegalArgumentException ex) {
                gui.showError("Error: " + ex.getMessage());
            } catch (Exception ex) {
                gui.showError("An unexpected error occurred: " + ex.getMessage());
            }
        }
    }
                class UpdateButtonListener implements ActionListener {
                    @Override
                    public void actionPerformed(ActionEvent e) {
                        try {
                            String patientIdStr = JOptionPane.showInputDialog("Enter patient ID to update:");
                            if (patientIdStr != null) {
                                int patientId = Integer.parseInt(patientIdStr);
                                Patient patient = doctor.getPatientById(patientId);
                                if (patient != null) {
                                    String name = gui.getPatientName();
                                    String surname = gui.getPatientSurname();
                                    int age = gui.getPatientAge();
                                    String contactInfo = gui.getPatientContact();
                                    String gender = gui.getPatientGender();
                                    String doctorCategory = gui.getPatientDoctorCategory();
                                    patient.setName(name);
                                    patient.setSurname(surname);
                                    patient.setAge(age);
                                    patient.setContactInfo(contactInfo);
                                    patient.setGender(gender);
                                    patient.setDoctorCategory(doctorCategory);
                                    gui.displayPatientInfo("Patient updated: " + patient.getName()+ " " + patient.getSurname() + "with ID :" + patient.getPatientId()+"\n, Age: "+patient.getAge()+", Cont. Info: "+ patient.getContactInfo()+", Gender "+patient.getGender()+", Doc. Category "+patient.getDoctorCategory());
                                    gui.showError("Patient Updated Successfully (≧ヮ≦) \uD83D\uDC95");
                                } else {
                                    gui.showError("Patient ID not found.");
                                }
                            }
                        } catch (NumberFormatException ex) {
                            gui.showError("Invalid patient ID format.");
                        } catch (Exception ex) {
                            gui.showError("Error updating patient: " + ex.getMessage());
                        }
                    }
                }


                class DeleteButtonListener implements ActionListener {
                    @Override
                    public void actionPerformed(ActionEvent e) {
                        try {
                            String patientIdStr = JOptionPane.showInputDialog("Enter patient ID to delete:");
                            if (patientIdStr != null) {
                                int patientId = Integer.parseInt(patientIdStr);
                                Patient patient = doctor.getPatientById(patientId);
                                if (patient != null) {
                                    doctor.getPatients().remove(patient);
                                    gui.displayPatientInfo("Patient deleted: " + patient.getName() + " " + patient.getSurname() + " with ID " + patient.getPatientId()+"\n, Age: "+patient.getAge()+", Cont. Info: "+ patient.getContactInfo()+", Gender "+patient.getGender()+", Doc. Category "+patient.getDoctorCategory());
                                    gui.showError("Patient Deleted Successfully o( ˶^▾^˶ )o");
                                } else {
                                    gui.showError("Patient ID not found.");
                                }
                            }
                        } catch (NumberFormatException ex) {
                            gui.showError("Invalid patient ID format.");
                        } catch (Exception ex) {
                            gui.showError("Error deleting patient: " + ex.getMessage());
                        }
                    }
                }


                class FetchPatientDetailsListener implements ActionListener {
                    @Override
                    public void actionPerformed(ActionEvent e) {
                        try {
                            String patientIdStr = gui.getDoctorPatientId();
                            if (patientIdStr != null && !patientIdStr.isEmpty()) {
                                int patientId = Integer.parseInt(patientIdStr);
                                Patient patient = doctor.getPatientById(patientId);
                                if (patient != null) {
                                    gui.displayDoctorInfo("┬┴┬┴┤ᵒᵏ (･_├┬┴┬┴┬┴┬┴┤├┬┴┬┴┬┴┬┴┤├┬┴┬┴┬┴┬┴┤├┬┴┬┴┬┴┬┴┤"+"\nPatient details: \n" + patientDetails(patient));
                                } else {
                                    gui.showError("Patient ID not found.");
                                }
                            } else {
                                gui.showError("Patient ID cannot be empty.");
                            }
                        } catch (NumberFormatException ex) {
                            gui.showError("Invalid patient ID format.");
                        } catch (Exception ex) {
                            gui.showError("Error fetching patient details: " + ex.getMessage());
                        }
                    }

                    private String patientDetails(Patient patient) {
                        return "ID: " + patient.getPatientId() + "\n" +
                                "Name: " + patient.getName() + "\n" +
                                "Surname: " + patient.getSurname() + "\n" +
                                "Age: " + patient.getAge() + "\n" +
                                "Contact Info: " + patient.getContactInfo() + "\n" +
                                "Gender: " + patient.getGender() + "\n" +
                                "Doctor Category: " + patient.getDoctorCategory();
                    }
                }


                class PrescriptionButtonListener implements ActionListener {
                    @Override
                    public void actionPerformed(ActionEvent e) {
                        try {
                            String patientIdStr = gui.getDoctorPatientId();
                            if (patientIdStr != null && !patientIdStr.isEmpty()) {
                                int patientId = Integer.parseInt(patientIdStr);
                                Patient patient = doctor.getPatientById(patientId);
                                if (patient != null) {
                                    String prescription = JOptionPane.showInputDialog("Enter prescription:");
                                    gui.displayDoctorInfo("ᕙ(⇀‸↼‶)ᕗ Prescription added for patient ID :" + patient.getPatientId() +" is "+prescription);
                                } else {
                                    gui.showError("Patient ID not found.");
                                }
                            } else {
                                gui.showError("Patient ID cannot be empty.");
                            }
                        } catch (NumberFormatException ex) {
                            gui.showError("Invalid patient ID format.");
                        } catch (Exception ex) {
                            gui.showError("Error adding prescription: " + ex.getMessage());
                        }
                    }
                }


                class CommentsButtonListener implements ActionListener {
                    @Override
                    public void actionPerformed(ActionEvent e) {
                        try {
                            String patientIdStr = gui.getDoctorPatientId();
                            if (patientIdStr != null && !patientIdStr.isEmpty()) {
                                int patientId = Integer.parseInt(patientIdStr);
                                Patient patient = doctor.getPatientById(patientId);
                                if (patient != null) {
                                    String comments = JOptionPane.showInputDialog("Enter comments:");
                                    gui.displayDoctorInfo("Comments added from "+ doctor.getName()+" to "+ patient.getName()+ ". Doctor commented :" + comments+" （＾ω＾）");
                                    patient.getComments().add(comments);
                                } else {
                                    gui.showError("Patient ID not found.");
                                }
                            } else {
                                gui.showError("Patient ID cannot be empty.");
                            }
                        } catch (NumberFormatException ex) {
                            gui.showError("Invalid patient ID format.");
                        } catch (Exception ex) {
                            gui.showError("Error adding comments: " + ex.getMessage());
                        }
                    }
                }
                class NextCheckupButtonListener implements ActionListener {
                    @Override
                    public void actionPerformed(ActionEvent e) {
                        try {
                            String patientIdStr = gui.getDoctorPatientId();
                            if (patientIdStr != null && !patientIdStr.isEmpty()) {
                                int patientId = Integer.parseInt(patientIdStr);
                                Patient patient = doctor.getPatientById(patientId);
                                if (patient != null) {
                                    String nextCheckup = JOptionPane.showInputDialog("Enter next checkup date(dd/mm/yyyy) and time(hh.mm):");
                                    gui.displayDoctorInfo("(╥_╥) Next checkup added for patient ID " + patient.getPatientId() + " will be on : "+ nextCheckup);
                                } else {
                                    gui.showError("Patient ID not found.");
                                }
                            } else {
                                gui.showError("Patient ID cannot be empty.");
                            }
                        } catch (NumberFormatException ex) {
                            gui.showError("Invalid patient ID format.");
                        } catch (Exception ex) {
                            gui.showError("Error adding next checkup: " + ex.getMessage());
                        }
                    }
                }


}

