import java.util.ArrayList;
import java.util.List;
public class Doctor {
    private String category;
    private List<Patient> patients;
    private String name;
    public Doctor(String category,String name) {
        this.category = category;
        this.patients = new ArrayList<>();
        this.name=name;
    }
    public String getCategory() {
        return category;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setCategory(String category) {
        this.category = category;
    }
    public List<Patient> getPatients() {
        return patients;
    }
    public void addPatient(Patient patient) {
        patients.add(patient);
    }
    public Patient getPatientById(int id) {
        for (Patient patient : patients) {
            if (patient.getPatientId() == id) {
                return patient;
            }
        }
        return null;
    }
}

